<?php 
include_once('menu.php');
?>
<!DOCTYPE HTML>
<HTML>
<HEAD>
	<meta http-equiv="content-type" content="text/html; charset=UTF8" >
	<style>
	label {
		margin: 5px;
		padding: 5px;
		text-align: left;
		display: inline-block;
		min-width: 120px;
	}

	input {
		margin: 5px;
		padding: 5px;
		text-align: left;
		display: inline-flex;
		vertical-align: bottom;
	}
	</style>
</HEAD>
<BODY>

<h1>Üdvözlünk a könyvtárban!</h1>

<hr />
<?php
echo menu();
?>
<hr/>

<img src="old-books-436498_960_720.jpg" width="600" height="480" />

</BODY>
</HTML>
